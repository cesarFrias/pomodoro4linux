Interface do usuário
====================

Aqui estão os métodos que têm algum tipo de interação com o usuário.

Alguns exemplos são:
    - *_create_menu*
    - *_show_menu*
    - *_set_icon*
    - *_set_label*
    - *pause_timer*
    - *start_timer*
    - *update_timer*
    - *warn_coffee_break*

Acredito que seus nomes sejam expressivos o suficiente.

*TO_DO*:

    - Criar uma função para transformar segundos em minutos, aliviando assim o método: *warn_coffee_break*
