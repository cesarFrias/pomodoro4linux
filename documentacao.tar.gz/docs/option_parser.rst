*Option Parser*
===============

*Option Parser* é um módulo *python* usado para receber parâmetros via linha de comando.

Ele gera também o *help* do pomodoro.py para facilitar a experiência do usuário com o *software*.

Variáveis utilizadas:
    - *work*
    - *rest*
