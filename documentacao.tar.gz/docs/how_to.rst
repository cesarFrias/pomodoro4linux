Como usar (*How to*):
=====================

Caso você escolha usar o programa via linha de comando, os parâmetros *work* e *rest* deverão ser passados em
segundos.

Eles possuem um valor padrão sendo respectivamente, 1500 segundos (25 minutos) e 300 segundos (5 minutos).

Exemplos de uso:
    - python pomodoro.py -w 60 -r 30
    - python pomodoro.py --work 60 --rest 30
