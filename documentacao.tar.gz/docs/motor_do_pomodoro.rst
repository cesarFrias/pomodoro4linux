Motor do Pomodoro4linux
=======================

Aqui estão os métodos que não têm nenhuma interação com o usuário, eles são acessados através dos métodos em
*user_interface.py*.

Alguns exemplos são:
    - *start_timer*
    - *pause_timer*
    - *update_timer*
    - *option_parser*

Acredito que seus nomes sejam expressivos o suficiente.
