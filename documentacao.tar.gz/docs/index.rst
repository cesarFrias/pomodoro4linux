.. pomodoro4linux documentation master file, created by
   sphinx-quickstart on Sun Sep  5 14:58:55 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Bem-vindo à documentação do pomodoro4linux
==========================================

O que é:
    *Pomodoro* é uma técnica para melhor gerenciar seu tempo útil.

    São utilizados ciclos de 25 minutos para trabalho e 5 minutos para cada descanso. A cada
    5 ciclos completos você pode descansar durante 25 minutos.

Conteúdo:

.. toctree::
   :maxdepth: 4

   interface_de_usuario.rst
   motor_do_pomodoro.rst
   option_parser.rst
   how_to.rst
